<?php
/**
 * Setting Lexicon Entries for TimerangeTV
 *
 * @package timerangetv
 * @subpackage lexicon
 */
$_lang['setting_timerangetv.debug'] = 'Debug';
$_lang['setting_timerangetv.debug_desc'] = 'Log debug information in the MODX error log.';
