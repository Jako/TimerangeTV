<?php
/**
 * Setting Lexicon Entries for TimerangeTV
 *
 * @package timerangetv
 * @subpackage lexicon
 */

$_lang['setting_timerangetv.debug'] = 'Foutoplossing';
$_lang['setting_timerangetv.debug_desc'] = 'Log debug/foutopsporings informatie in het foutenlogboek van MODX.';
