<?php
/**
 * Setting Lexicon Entries for TimerangeTV
 *
 * @package timerangetv
 * @subpackage language
 */
$_lang['setting_timerangetv.debug'] = 'Debug';
$_lang['setting_timerangetv.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
