--------------------
TimerangeTV
--------------------
Since: August 27th, 2012
Author: Bert Oost at OostDesign.nl <bert@oostdesign.nl>

A template variable input type to create a timerange input

Please see the GIT project: https://github.com/bertoost/MODX-TimerangeTV