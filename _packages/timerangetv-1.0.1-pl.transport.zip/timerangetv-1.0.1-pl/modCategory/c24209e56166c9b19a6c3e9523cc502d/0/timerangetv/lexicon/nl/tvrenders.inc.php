<?php

$_lang['timerange'] = "Tijdreeks (van <> tot)";
$_lang['timerangetv.from'] = "Van tijd";
$_lang['timerangetv.to'] = "Tot tijd";
$_lang['timerangetv.time_increment'] = "Tijdsinterval";
$_lang['timerangetv.time_increment_desc'] = "De interval in minuten voor de tijdslijst. Standaard ingesteld op 60.";
$_lang['timerangetv.time_format'] = "Tijdsformaat";
$_lang['timerangetv.time_format_desc'] = "Het formaat moet voldoen aan <a href=\"http://docs.sencha.com/ext-js/3-4/#!/api/Date-static-method-parseDate\" target=\"_blank\">Date.parseDate</a> (standaard \"g:i A\", gelijk aan, \"3:15 PM\"). Voor 24-uur formaat gebruik \"H:i\".";

?>